import pandas as pd
import matplotlib.pyplot as plt
import re
from pylab import *

f = pd.read_csv(r'C:\Users\elyod\OneDrive\Desktop\Douban\result\task5_1_JCS.csv')
days = pd.DataFrame(pd.to_datetime(f['one']) - pd.to_datetime(f['join_time']))
print(days)

list = days[0].tolist()
days_list = re.findall('Timedelta\(\'(.*?) days 00:00:00',str(list))

nums =[]
for m in days_list:
    m = int(m)
    nums.append(m)
print(nums)


f['会龄'] = nums
print(f)

#分类计数
field = []
for k in range(0,14):
    a1 = k
    a2 = k+1
    field1 = str(a1) +"-"+ str(a2)
    print(field1)
    field.append(field1)
print(field)

scores_list = f['scores'].tolist()
print(scores_list)
mean_list = []
for k in range(0,14):
    num1 = 0
    s = 0
    mean = 0
    for i in range(len(nums)):
        if (nums[i]>=365*k)&(nums[i]<=365*(k+1)):
            num1 =num1+1
            s = s + scores_list[i]
            mean = float("{:.1f}".format(s/num1))
    mean_list.append(mean)
print(mean_list)

# 绘图
x = range(len(field))
mpl.rcParams['font.sans-serif'] = ['SimHei']
plt.plot(x, mean_list, marker='o', mec='b', mfc='w')
plt.xticks(x, field)

for a, b in zip(x, mean_list):
     plt.text(a, b, b, ha='center', va='bottom', fontsize=10)
plt.subplots_adjust(bottom=0.15)
plt.xlabel("会龄区间（单位：年）") 
plt.ylabel("评分均分") 
plt.title("复联4不同会龄评分意向")

plt.savefig("../result/task5_3.jpg")
plt.show()