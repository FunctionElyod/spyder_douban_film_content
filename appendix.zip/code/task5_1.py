import pandas as pd
import matplotlib.pyplot as plt
import re
from pylab import *

f = pd.read_excel(r'C:\Users\elyod\OneDrive\Desktop\Douban\result\task1.xlsx')
f = pd.DataFrame(f)
two = f.ix[:,['join_time','con_time','scores']]
print(two)
two['con_time'] = two['con_time'].astype(str)

m = pd.DataFrame((x.split(' ') for x in two['con_time']),index = two.index,columns = ['one','two'])
two['one'] = m['one']
two['two'] = m['two']
print(two)

two.to_csv('../result/task5_1_JCS.csv',encoding='utf-8_sig')