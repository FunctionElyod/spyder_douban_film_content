import pandas as pd
import matplotlib.pyplot as plt
import re
from pylab import *

f = pd.read_excel(r'C:\Users\elyod\OneDrive\Desktop\Douban\result\task1.xlsx')
f = pd.DataFrame(f)
two = f['con_time']

two = pd.to_datetime(two,format = '%Y%m%d %H:%M:%S')
print(two)

two = pd.DataFrame(two, columns=["con_time"])
two['con_time'] = two['con_time'].astype(str)
m = pd.DataFrame((x.split(' ') for x in two['con_time']),index = two.index,columns = ['one','two'])

print(m)
print('-'*20)

#one降序
print(m.dtypes)
m = m.sort_values(by = 'one')
print(m)
print('-'*20)


result = m["one"].tolist()
List = result
d1 = {}
for i in List:
    if List.count(i) >= 1:
        d1[i] = List.count(i)
print(d1)
print('-'*20)
riqi,number1 = d1.keys(),d1.values()
print(riqi)
print(number1)

names = riqi
name_list1 = re.findall('\d{4}-\d{2}-\d{2}', str(names))
print(name_list1)
x = range(len(name_list1))
print(x)

number_list1 = re.findall('\d+\d*\d*', str(number1))
y1 = number_list1
print(y1)
y = []
for i in range(len(y1)):
   y2 = float(y1[i])
   y.append(int(y2))
print(y)

plt.plot(name_list1, y, marker='o', mec='r', mfc='w')

mpl.rcParams['font.sans-serif'] = ['SimHei']
plt.xticks(x, names, rotation=45)

for a, b in zip(x, y):
     plt.text(a, b, b, ha='center', va='bottom', fontsize=10)
plt.subplots_adjust(bottom=0.15)
plt.xlabel("发表日期")
plt.ylabel("短评数量") 
plt.title("复联4短评数量与日期变化关系") 

plt.savefig('../result/task3_1')
plt.show()