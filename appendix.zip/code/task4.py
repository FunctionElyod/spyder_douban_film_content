import pandas as pd
from pyecharts import Geo
 
#读取数据
datafile = r'C:\Users\elyod\OneDrive\Desktop\douban_spider\result\city1.xlsx'
data = pd.read_excel(datafile)
attr = data['City']
value = data['Score']
 
geo = Geo("《复联4》短评用户常居城市分布", title_color="#2E2E2E",
          title_text_size=24,title_top=20,title_pos="center", width=1300,height=600, 
          background_color='#F6CEF5')
geo.add("", attr, value, type="effectScatter", is_random=True, visual_range=[0, 100], 
        maptype='china',visual_text_color="#FF0000", geo_normal_color="#6E6E6E",geo_emphasis_color='#F5D0A9',
        symbol_size=8, effect_scale=5, is_visualmap=True)
 
geo.render(path=r'C:\Users\elyod\OneDrive\Desktop\douban_spider\result\task4.html')#生成html文件
