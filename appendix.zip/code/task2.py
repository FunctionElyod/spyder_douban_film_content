import matplotlib.pyplot as plt
from wordcloud import WordCloud
import jieba

text_from_file_with_apath = open(r'/Users/elyod/Downloads/content.txt').read()

wordlist_after_jieba = jieba.cut(text_from_file_with_apath, cut_all = True)
wl_space_split = " ".join(wordlist_after_jieba)

seg_list = list(jieba.cut(wl_space_split, cut_all=False))
result = []
for word in seg_list:
    if len(word) > 1:
        if word == '我们' or word == '他们' or word == '一个' or word == '电影':
            continue
        result.append(word)

result = '\n'.join(result)

wc1 = WordCloud(
    background_color="white",
    width=2000,
    height=1500,
    font_path="C:\\Windows\\Fonts\\STFANGSO.ttf",#不加这一句显示口字形乱码
    margin=2)
wc2 = wc1.generate(result)

plt.imshow(wc2)
plt.axis("off")
plt.show()