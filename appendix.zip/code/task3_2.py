import pandas as pd
import matplotlib.pyplot as plt
import re
from pylab import *

opene = pd.read_excel(r'C:\Users\elyod\OneDrive\Desktop\Douban\result\task1.xlsx')
data = pd.DataFrame(opene)
print(data)
data['time'] = pd.to_datetime(data['con_time']).apply(lambda x: x.hour)
print(data['time'])
num = data['time'].value_counts().sort_index()
print(num)
y = num.tolist()
print(y)
x =range(len(y))
print(x)

plt.plot(x,y,marker='o', mec='r', mfc='w')
plt.xticks(x, x)

plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False#防乱码
for a, b in zip(x, y):
     plt.text(a, b, b, ha='center', va='bottom', fontsize=10)
plt.subplots_adjust(bottom=0.15)
plt.xlabel('发表时刻')
plt.ylabel('短评数量')
plt.title('复联4用户短评数量与时刻变化关系')

plt.savefig('../result/task3_2')
plt.show()