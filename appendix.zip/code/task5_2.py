import pandas as pd
import matplotlib.pyplot as plt
import re
from pylab import *

f = pd.read_csv(r'C:\Users\elyod\OneDrive\Desktop\Douban\result\task5_1_JCS.csv')
days = pd.DataFrame(pd.to_datetime(f['one']) - pd.to_datetime(f['join_time']))
print(days)

list = days[0].tolist()
days_list = re.findall('Timedelta\(\'(.*?) days 00:00:00',str(list))

nums =[]
for m in days_list:
    m = int(m)
    nums.append(m)
print(nums)
nums.sort()
print(nums)
print(len(nums))
max=nums[len(nums)-1]
min=nums[0]

#分类计数
field = []
for k in range(0,14):
    a1 = k
    a2 = k+1
    field1 = str(a1) +"-"+ str(a2)
    print(field1)
    field.append(field1)
print(field)

site =[]
for k in range(0,14):
    num1 =0
    for m in nums:
        if (m>=365*k)&(m<=365*(k+1)):
            num1 =num1+1
    site.append(num1)
print(site)
print(sum(site))

#绘图
mpl.rcParams['font.sans-serif'] = ['SimHei']
def draw_bar(labels, quants):
    width = 0.4
    ind = np.linspace(0.5, 9.5, 14)
    fig = plt.figure(1)
    ax = fig.add_subplot(111)
    ax.bar(ind - width / 2, quants, width, color='blue')
    ax.set_xticks(ind)
    ax.set_xticklabels(labels)
    ax.set_xlabel('会龄区间（单位：年）')
    ax.set_ylabel('人数')
    ax.set_title('复联4会龄分布柱状图', bbox={'facecolor': '0.8', 'pad': 5})
    plt.grid(True)
    plt.savefig("../result/task5_2.jpg")
    plt.show()
    plt.close()
    
labels = field
quants = site
draw_bar(labels, quants)